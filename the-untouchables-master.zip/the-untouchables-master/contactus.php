<style>
	table{padding:5px;border-radius:5px}
	td{padding:10px}
</style>
<table width="90%" border="1" align="center">
  <tr style="background:#CCCCCC" height="30px">
    <th colspan="2" style="color:#0000FF">Contact Us</th>
  </tr>
  <tr>
    <td width="121" height="37">Name</td>
    <td width="252">The Untouchables </td>
  </tr>
  <tr>
    <td height="36">Phone </td>
    <td> 1-800-getlost </td>
  </tr>
  <tr>
    <td>Anything</td>
    <td>1234 Somewhere in the world</td>
  </tr>
    <tr>
    <td>Email</td>
    <td>some email</td>
  </tr>
   <tr>
    <td>Website</td>
    <td><a href="http://www.somesite.com">www.somesite.com</a></td>
  </tr>
  
</table>
