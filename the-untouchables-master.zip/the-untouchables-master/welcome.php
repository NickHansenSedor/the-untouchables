 <?php session_start();
 
 	echo "<h3>Welcme ".$_SESSION['sname']."</h3>";
 ?>
Your account has beeb created 
to access your accout <a href="index.php?chk=login">Click here</a></h2>